package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;

@RestController
@RequestMapping("/applicants")
public class ApplicantController {
	
	
	@Autowired
	ApplicantService applicantService;
	
	public ApplicantController() {
		System.out.println("ApplicantController() constructor...");
	}
	
	@RequestMapping("/get") // localhost:8080/emps/getEmps
	public List<Applicant> getAllApplicants() {
		System.out.println("/getApplicants");
		return applicantService.getAllApplicants();
	}
	
	@RequestMapping("/find{appNo}")
	public Applicant getApplicant(@PathVariable ("appNo") int applicantId) {
		
		return applicantService.getApplicant(applicantId);
	}
	
	@RequestMapping("update")
	public String updateApplicant(@RequestBody Applicant applicantObj) {
		
		if(applicantService.updateApplicant(applicantObj))
			return "Applicant udated";
		else
			return "Applicant not updated";
		
	}
	@RequestMapping("remove")
	public String removeApplicant(@PathVariable int applicantId) {
	
		if(applicantService.removeApplicant(applicantId))
			return "Applicant removed";
		else
			return "Applicant not removed";
	}
	
	
	
	/*
	@RequestMapping("/getEmp/{eno}") // localhost:8080/emps/getEmp/7839
	public Employee getEmployee(@PathVariable("eno") int employeeNumberToSearch) {
		System.out.println("/getEmp");
		boolean employeeFound=false;
		Employee employeeObject = null;
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber() == employeeNumberToSearch) {
				employeeFound = true;
				break;
			}
		}
		if(employeeFound==true)	return employeeObject;	
		else	
			throw new RuntimeException("Employee Not Found");
	}
	
	@RequestMapping("/deleteEmp/{eno}") // localhost:8080/emps/deleteEmp/7839
	public String deleteEmployee(@PathVariable("eno") int employeeNumberToDelete) {
		System.out.println("/deleteEmp");
		boolean employeeFound=false;
		Employee employeeObject = null;
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber() == employeeNumberToDelete) {
				employeeFound = true;	staff.remove(i);	break;
			}
		}
		if(employeeFound==true)	
				return "Employee Object deleted : "+employeeNumberToDelete;
		else
			return "Employee Object NOT found : "+employeeNumberToDelete;
	}
	
	@RequestMapping("/updateEmp") // localhost:8080/emps/updateEmp/7839
	public String updateEmployee(@RequestBody Employee employeeObjectToModify) {
		System.out.println("/updateEmp");
		boolean employeeFound=false;
		Employee employeeObject = null;
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber() == employeeObjectToModify.getEmployeeNumber()) {
				employeeFound = true;
				staff.remove(i);
				staff.add(employeeObjectToModify);
				break;
			}
		}
		if(employeeFound==true)	
			return "Employee Object successfully modified"; 
		else
			return "Employee Object NOT found : "+employeeObjectToModify.getEmployeeNumber(); 
				
	}
	
	@RequestMapping("/addEmp") // localhost:8080/emps/updateEmp/7839
	public String addEmployee(@RequestBody Employee employeeObjectToAdd) {
		System.out.println("/addEmp");
		boolean employeeFound=false;
		Employee employeeObject = null;
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber() == employeeObjectToAdd.getEmployeeNumber()) {
				employeeFound = true;
				break;
			}
		}
		if(employeeFound==true)	
			return "Employee with this employeeNumber already exists!!!"; 
		else {
			staff.add(employeeObjectToAdd);
			return "Employee Object addedd succesfully : ";
		}
				
	}
	*/
}
