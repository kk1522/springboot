package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;


@Service
public interface ApplicantService {
	void createApplicationService(Applicant app);
	List<Applicant> getAllApplicants();
	Applicant getApplicant(int applicantId);
	Boolean updateApplicant(Applicant applicant);
	Boolean removeApplicant(int applicantId);
}
