package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;


@Service
public class ApplicantServiceImpl implements ApplicantService {

	@Autowired
	ApplicantRepository appRepo;
	
	@Override
	public void createApplicationService(Applicant app) {
		
		appRepo.createApplication(app);
		System.out.println("ApplicantServiceImpl() : created the applicants data.....");

	}
	
	public List<Applicant> getAllApplicants() {
		
		return appRepo.findAllApplicants();
		
	}
	
	public Applicant getApplicant(int applicantId) {
		
		return appRepo.findApplication(applicantId);
	}
	
	public Boolean updateApplicant(Applicant applicant) {
		
		if(appRepo.findApplication(applicant.getApplicantId())!=null) {
			appRepo.removeApplication(applicant.getApplicantId());
			appRepo.createApplication(applicant);
			return true;
		}
		else {
			return false;
		}	
	}
	
	public Boolean removeApplicant(int applicantId) {
		if(appRepo.findApplication(applicantId)!=null) {
			appRepo.removeApplication(applicantId);
			return true;
		}
		else
			return false;
		
	}
	
	

}
